import { useCallback } from 'react';

/**
 * Custom hook to render mathematical formulas using MathJax
 */
export default function useMathJax() {
  /**
   * Render math formula in the DOM element
   * @param element DOM element containing formula to render
   */
  const renderMath = useCallback((element: HTMLElement) => {
    if (window.MathJax) {
      // Make sure MathJax is fully loaded before trying to render
      if (window.MathJax.typesetPromise) {
        try {
          window.MathJax.typesetPromise([element]).catch((err) => 
            console.error('MathJax error:', err)
          );
        } catch (error) {
          console.error('Error rendering math formula:', error);
        }
      } else {
        // If MathJax is not fully loaded yet, try again after a short delay
        setTimeout(() => renderMath(element), 500);
      }
    }
  }, []);

  return { renderMath };
}

// Add MathJax to window type
declare global {
  interface Window {
    MathJax: {
      typesetPromise: (elements: HTMLElement[]) => Promise<any>;
    };
  }
}
