import React, { useEffect, useState, useRef, forwardRef, useImperativeHandle } from 'react';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';
import Formula from '@/components/Formula';

interface MathEquationEditorProps {
  initialValue?: string;
  onChange?: (value: string) => void;
  className?: string;
  placeholder?: string;
}

export interface MathEquationEditorRef {
  getValue: () => string;
  setValue: (value: string) => void;
  focus: () => void;
}

const MathEquationEditor = forwardRef<MathEquationEditorRef, MathEquationEditorProps>((
  { initialValue = '', onChange, className = '', placeholder = 'Enter a mathematical expression...' },
  ref
) => {
  const [expression, setExpression] = useState<string>(initialValue);
  const [preview, setPreview] = useState<string>('');
  const inputRef = useRef<HTMLInputElement>(null);
  
  useEffect(() => {
    // Format the expression for preview
    if (expression) {
      // Create a formatted version for the LaTeX preview
      let formatted = expression
        .replace(/\^(\d+|[a-zA-Z])/g, '^{$1}') // Add braces to powers
        .replace(/sqrt\(/g, '\\sqrt{') // Format sqrt
        .replace(/\)/g, '}') // Close sqrt braces
        .replace(/\*/g, '\\cdot '); // Format multiplication

      setPreview(formatted);
    } else {
      setPreview('');
    }
  }, [expression]);

  useImperativeHandle(ref, () => ({
    getValue: () => expression,
    setValue: (newValue: string) => {
      setExpression(newValue);
    },
    focus: () => {
      if (inputRef.current) {
        inputRef.current.focus();
      }
    }
  }));

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setExpression(value);
    if (onChange) {
      onChange(value);
    }
  };

  return (
    <div className={cn(
      "math-input-container w-full",
      className
    )}>
      <Input
        ref={inputRef}
        value={expression}
        onChange={handleChange}
        placeholder={placeholder}
        className="w-full mb-2 font-mono"
      />
      {preview && (
        <div className="p-2 bg-gray-50 rounded-md border border-gray-200 min-h-[40px] mt-1">
          <Formula formula={preview} />
        </div>
      )}
    </div>
  );
});

MathEquationEditor.displayName = 'MathEquationEditor';

export default MathEquationEditor;
