import { Link } from "wouter";
import Formula from "./Formula";

interface FormulaCardProps {
  title: string;
  formula: string;
  description: string;
  link: string;
}

export default function FormulaCard({ title, formula, description, link }: FormulaCardProps) {
  return (
    <div className="formula-card bg-white rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-all">
      <div className="p-5 border-b border-gray-200 bg-primary/5">
        <h3 className="text-lg font-semibold text-primary">{title}</h3>
      </div>
      <div className="p-5">
        <Formula formula={formula} />
        <p className="text-sm text-gray-600 mt-2">{description}</p>
        <Link href={link}>
          <span className="mt-4 inline-block text-primary hover:underline cursor-pointer">Learn more →</span>
        </Link>
      </div>
    </div>
  );
}
