import React, { useEffect, useRef, forwardRef, useImperativeHandle } from 'react';
import { cn } from '@/lib/utils';
import 'mathlive';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'math-field': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement> & {
        ref?: React.RefObject<any>;
      };
    }
  }
}

// Declare the MathField type
interface MathfieldElement extends HTMLElement {
  value: string;
  readOnly: boolean;
  focus(): void;
  select(): void;
  executeCommand(command: string): boolean;
}

interface MathLiveEditorProps {
  initialValue?: string;
  onChange?: (value: string) => void;
  className?: string;
  placeholder?: string;
  readOnly?: boolean;
}

export interface MathLiveEditorRef {
  getValue: () => string;
  setValue: (value: string) => void;
  focus: () => void;
  clear: () => void;
}

const MathLiveEditor = forwardRef<MathLiveEditorRef, MathLiveEditorProps>((
  { 
    initialValue = '', 
    onChange, 
    className = '', 
    placeholder = 'Enter a mathematical expression...', 
    readOnly = false 
  },
  ref
) => {
  const mathFieldRef = useRef<MathfieldElement | null>(null);
  
  useEffect(() => {
    const mathField = mathFieldRef.current;
    if (mathField) {
      // Set initial value
      mathField.value = initialValue;
      
      // Set up event listener for changes
      mathField.addEventListener('input', () => {
        if (onChange && mathField) {
          onChange(mathField.value);
        }
      });
    }
  }, [initialValue, onChange]);
  
  useImperativeHandle(ref, () => ({
    getValue: () => mathFieldRef.current ? mathFieldRef.current.value : '',
    setValue: (newValue: string) => {
      if (mathFieldRef.current) {
        mathFieldRef.current.value = newValue;
      }
    },
    focus: () => {
      if (mathFieldRef.current) {
        mathFieldRef.current.focus();
      }
    },
    clear: () => {
      if (mathFieldRef.current) {
        mathFieldRef.current.value = '';
        mathFieldRef.current.focus();
      }
    }
  }));

  useEffect(() => {
    const mathField = mathFieldRef.current;
    if (mathField && placeholder) {
      // Set aria-placeholder instead as the custom element doesn't properly support placeholder
      mathField.setAttribute('aria-placeholder', placeholder);
    }
  }, [placeholder]);

  return (
    <div className={cn("math-editor-container", className)}>
      <math-field
        // @ts-ignore - TypeScript doesn't recognize custom properties because of custom element
        ref={mathFieldRef}
      />
    </div>
  );
});

MathLiveEditor.displayName = 'MathLiveEditor';

export default MathLiveEditor;
