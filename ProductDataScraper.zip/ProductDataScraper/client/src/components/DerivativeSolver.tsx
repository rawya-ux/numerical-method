import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Formula from "@/components/Formula";
import useMathJax from "@/hooks/useMathJax";
import MathLiveEditor, { MathLiveEditorRef } from "@/components/MathLiveEditor";
import * as math from 'mathjs';

type DifferentiationMethod = 'forward' | 'backward' | 'central' | 'forward-oh2' | 'backward-oh2' | 'central-oh4';

interface SolverFormData {
  functionExpression: string;
  xValue: string;
  stepSize: string;
  method: DifferentiationMethod;
}

interface SolutionStep {
  explanation: string;
  formula?: string;
  value?: string;
}

export default function DerivativeSolver() {
  const { renderMath } = useMathJax();
  const containerRef = useRef<HTMLDivElement>(null);
  
  const [formData, setFormData] = useState<SolverFormData>({
    functionExpression: 'x^2',
    xValue: '2',
    stepSize: '0.1',
    method: 'central',
  });
  
  const [solutionSteps, setSolutionSteps] = useState<SolutionStep[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<number | null>(null);
  const [exactResult, setExactResult] = useState<number | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const mathFieldRef = useRef<MathLiveEditorRef>(null);
  
  useEffect(() => {
    if (containerRef.current) {
      renderMath(containerRef.current);
    }
  }, [renderMath, solutionSteps]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleMathExpressionChange = (value: string) => {
    setFormData(prev => ({ ...prev, functionExpression: value }));
  };

  const handleMethodChange = (value: string) => {
    setFormData(prev => ({ ...prev, method: value as DifferentiationMethod }));
  };

  const validateInput = () => {
    try {
      // Parse the function expression
      const node = math.parse(formData.functionExpression);
      const code = node.compile();
      
      // Test if the function works at x value
      const x = parseFloat(formData.xValue);
      code.evaluate({ x });
      
      // Validate step size
      const h = parseFloat(formData.stepSize);
      if (isNaN(h) || h <= 0) {
        throw new Error("Step size must be a positive number");
      }
      
      return true;
    } catch (err) {
      setError(`Invalid input: ${err instanceof Error ? err.message : String(err)}`);
      return false;
    }
  };

  // Helper function to safely evaluate the function
  const evaluateFunction = (expression: string, xVal: number): number => {
    try {
      const node = math.parse(expression);
      const code = node.compile();
      return code.evaluate({ x: xVal });
    } catch (err) {
      throw new Error(`Could not evaluate function at x=${xVal}: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  const calculateDerivative = () => {
    setError(null);
    setSolutionSteps([]);
    setResult(null);
    setExactResult(null);
    setIsCalculating(true);
    
    try {
      if (!validateInput()) {
        setIsCalculating(false);
        return;
      }

      const functionExpr = formData.functionExpression;
      const x = parseFloat(formData.xValue);
      const h = parseFloat(formData.stepSize);
      const method = formData.method;
      
      // Try to calculate exact derivative
      try {
        const derivative = math.derivative(functionExpr, 'x');
        const exactValue = evaluateFunction(derivative.toString(), x);
        setExactResult(exactValue);
      } catch (err) {
        // It's okay if exact derivative fails
        console.log("Couldn't calculate exact derivative:", err);
      }
      
      let steps: SolutionStep[] = [];
      let approximateResult: number;
      
      steps.push({
        explanation: `Step 1: Identify the function to differentiate`,
        formula: `f(x) = ${functionExpr}`
      });
      
      steps.push({
        explanation: `Step 2: Identify the point of evaluation and step size`,
        formula: `x = ${x}, \\quad h = ${h}`
      });

      // Calculate the numerical derivative based on the selected method
      switch (method) {
        case 'forward':
          steps.push({
            explanation: `Step 3: Apply the forward difference formula for the first derivative`,
            formula: `f'(x) \\approx \\frac{f(x+h) - f(x)}{h}`
          });
          
          const fx = evaluateFunction(functionExpr, x);
          const fxPlusH = evaluateFunction(functionExpr, x + h);
          
          steps.push({
            explanation: `Step 4: Calculate f(${x})`,
            formula: `f(${x}) = ${fx.toFixed(6)}`
          });
          
          steps.push({
            explanation: `Step 5: Calculate f(${x + h})`,
            formula: `f(${x + h}) = ${fxPlusH.toFixed(6)}`
          });
          
          approximateResult = (fxPlusH - fx) / h;
          
          steps.push({
            explanation: `Step 6: Calculate the derivative approximation`,
            formula: `f'(${x}) \\approx \\frac{${fxPlusH.toFixed(6)} - ${fx.toFixed(6)}}{${h}} = \\frac{${(fxPlusH - fx).toFixed(6)}}{${h}} = ${approximateResult.toFixed(6)}`
          });
          break;
          
        case 'backward':
          steps.push({
            explanation: `Step 3: Apply the backward difference formula for the first derivative`,
            formula: `f'(x) \\approx \\frac{f(x) - f(x-h)}{h}`
          });
          
          const fxBackward = evaluateFunction(functionExpr, x);
          const fxMinusH = evaluateFunction(functionExpr, x - h);
          
          steps.push({
            explanation: `Step 4: Calculate f(${x})`,
            formula: `f(${x}) = ${fxBackward.toFixed(6)}`
          });
          
          steps.push({
            explanation: `Step 5: Calculate f(${x - h})`,
            formula: `f(${x - h}) = ${fxMinusH.toFixed(6)}`
          });
          
          approximateResult = (fxBackward - fxMinusH) / h;
          
          steps.push({
            explanation: `Step 6: Calculate the derivative approximation`,
            formula: `f'(${x}) \\approx \\frac{${fxBackward.toFixed(6)} - ${fxMinusH.toFixed(6)}}{${h}} = \\frac{${(fxBackward - fxMinusH).toFixed(6)}}{${h}} = ${approximateResult.toFixed(6)}`
          });
          break;
          
        case 'central':
          steps.push({
            explanation: `Step 3: Apply the central difference formula for the first derivative`,
            formula: `f'(x) \\approx \\frac{f(x+h) - f(x-h)}{2h}`
          });
          
          const fxPlusHCentral = evaluateFunction(functionExpr, x + h);
          const fxMinusHCentral = evaluateFunction(functionExpr, x - h);
          
          steps.push({
            explanation: `Step 4: Calculate f(${x + h})`,
            formula: `f(${x + h}) = ${fxPlusHCentral.toFixed(6)}`
          });
          
          steps.push({
            explanation: `Step 5: Calculate f(${x - h})`,
            formula: `f(${x - h}) = ${fxMinusHCentral.toFixed(6)}`
          });
          
          approximateResult = (fxPlusHCentral - fxMinusHCentral) / (2 * h);
          
          steps.push({
            explanation: `Step 6: Calculate the derivative approximation`,
            formula: `f'(${x}) \\approx \\frac{${fxPlusHCentral.toFixed(6)} - ${fxMinusHCentral.toFixed(6)}}{2 \\cdot ${h}} = \\frac{${(fxPlusHCentral - fxMinusHCentral).toFixed(6)}}{${2 * h}} = ${approximateResult.toFixed(6)}`
          });
          break;
          
        case 'forward-oh2':
          steps.push({
            explanation: `Step 3: Apply the O(h²) forward difference formula for the first derivative`,
            formula: `f'(x) \\approx \\frac{-f(x+2h) + 4f(x+h) - 3f(x)}{2h}`
          });
          
          const fx_forward_oh2 = evaluateFunction(functionExpr, x);
          const fxPlus1h = evaluateFunction(functionExpr, x + h);
          const fxPlus2h = evaluateFunction(functionExpr, x + 2*h);
          
          steps.push({
            explanation: `Step 4: Calculate required function values`,
            formula: `f(${x}) = ${fx_forward_oh2.toFixed(6)}\\\\
                      f(${x + h}) = ${fxPlus1h.toFixed(6)}\\\\
                      f(${x + 2*h}) = ${fxPlus2h.toFixed(6)}`
          });
          
          approximateResult = (-fxPlus2h + 4*fxPlus1h - 3*fx_forward_oh2) / (2*h);
          
          steps.push({
            explanation: `Step 5: Calculate the derivative approximation`,
            formula: `f'(${x}) \\approx \\frac{-${fxPlus2h.toFixed(6)} + 4 \\cdot ${fxPlus1h.toFixed(6)} - 3 \\cdot ${fx_forward_oh2.toFixed(6)}}{2 \\cdot ${h}} = ${approximateResult.toFixed(6)}`
          });
          break;
          
        case 'backward-oh2':
          steps.push({
            explanation: `Step 3: Apply the O(h²) backward difference formula for the first derivative`,
            formula: `f'(x) \\approx \\frac{3f(x) - 4f(x-h) + f(x-2h)}{2h}`
          });
          
          const fx_backward_oh2 = evaluateFunction(functionExpr, x);
          const fxMinus1h = evaluateFunction(functionExpr, x - h);
          const fxMinus2h = evaluateFunction(functionExpr, x - 2*h);
          
          steps.push({
            explanation: `Step 4: Calculate required function values`,
            formula: `f(${x}) = ${fx_backward_oh2.toFixed(6)}\\\\
                      f(${x - h}) = ${fxMinus1h.toFixed(6)}\\\\
                      f(${x - 2*h}) = ${fxMinus2h.toFixed(6)}`
          });
          
          approximateResult = (3*fx_backward_oh2 - 4*fxMinus1h + fxMinus2h) / (2*h);
          
          steps.push({
            explanation: `Step 5: Calculate the derivative approximation`,
            formula: `f'(${x}) \\approx \\frac{3 \\cdot ${fx_backward_oh2.toFixed(6)} - 4 \\cdot ${fxMinus1h.toFixed(6)} + ${fxMinus2h.toFixed(6)}}{2 \\cdot ${h}} = ${approximateResult.toFixed(6)}`
          });
          break;
          
        case 'central-oh4':
          steps.push({
            explanation: `Step 3: Apply the O(h⁴) central difference formula for the first derivative`,
            formula: `f'(x) \\approx \\frac{-f(x+2h) + 8f(x+h) - 8f(x-h) + f(x-2h)}{12h}`
          });
          
          const fxPlus2h_oh4 = evaluateFunction(functionExpr, x + 2*h);
          const fxPlus1h_oh4 = evaluateFunction(functionExpr, x + h);
          const fxMinus1h_oh4 = evaluateFunction(functionExpr, x - h);
          const fxMinus2h_oh4 = evaluateFunction(functionExpr, x - 2*h);
          
          steps.push({
            explanation: `Step 4: Calculate required function values`,
            formula: `f(${x + 2*h}) = ${fxPlus2h_oh4.toFixed(6)}\\\\
                      f(${x + h}) = ${fxPlus1h_oh4.toFixed(6)}\\\\
                      f(${x - h}) = ${fxMinus1h_oh4.toFixed(6)}\\\\
                      f(${x - 2*h}) = ${fxMinus2h_oh4.toFixed(6)}`
          });
          
          approximateResult = (-fxPlus2h_oh4 + 8*fxPlus1h_oh4 - 8*fxMinus1h_oh4 + fxMinus2h_oh4) / (12*h);
          
          steps.push({
            explanation: `Step 5: Calculate the derivative approximation`,
            formula: `f'(${x}) \\approx \\frac{-${fxPlus2h_oh4.toFixed(6)} + 8 \\cdot ${fxPlus1h_oh4.toFixed(6)} - 8 \\cdot ${fxMinus1h_oh4.toFixed(6)} + ${fxMinus2h_oh4.toFixed(6)}}{12 \\cdot ${h}} = ${approximateResult.toFixed(6)}`
          });
          break;
          
        default:
          throw new Error(`Unknown method: ${method}`);
      }
      
      // Add error analysis if exact derivative is available
      if (exactResult !== null) {
        const absoluteError = Math.abs(exactResult - approximateResult);
        const relativeError = Math.abs(absoluteError / exactResult) * 100;
        
        steps.push({
          explanation: `Error Analysis`,
          formula: `\\text{Exact value: } f'(${x}) = ${exactResult.toFixed(6)}\\\\
                    \\text{Absolute error: } |f'_{exact} - f'_{approx}| = ${absoluteError.toFixed(6)}\\\\
                    \\text{Relative error: } \\frac{|f'_{exact} - f'_{approx}|}{|f'_{exact}|} \\cdot 100\\% = ${relativeError.toFixed(4)}\\%`
        });
      }
      
      setSolutionSteps(steps);
      setResult(approximateResult);
      
    } catch (err) {
      setError(`Calculation error: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setIsCalculating(false);
    }
  };

  return (
    <div ref={containerRef}>
      <Card className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold font-inter mb-4 text-primary">Numerical Differentiation Solver</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <div className="mb-4">
              <Label htmlFor="functionExpression" className="block mb-2 font-medium">
                Function f(x)
              </Label>
              <div className="relative">
                <MathLiveEditor
                  ref={mathFieldRef}
                  initialValue={formData.functionExpression}
                  onChange={handleMathExpressionChange}
                  className="mb-1"
                  placeholder="Type your equation here..."
                />
                <button
                  onClick={() => mathFieldRef.current?.clear()}
                  className="ml-clear-button"
                  type="button"
                >
                  Clear
                </button>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Use x as variable. Supported functions: sin, cos, tan, sqrt, log, ln, exp, etc.
              </p>
              <p className="text-xs text-gray-500 mt-1">
                <span className="font-medium">Tips:</span> Use ^ for exponents, type "frac" for fractions, and "sqrt" for square roots.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <Label htmlFor="xValue" className="block mb-2 font-medium">
                  Evaluation Point (x)
                </Label>
                <Input
                  id="xValue"
                  name="xValue"
                  type="number"
                  value={formData.xValue}
                  onChange={handleInputChange}
                  className="w-full"
                />
              </div>
              
              <div>
                <Label htmlFor="stepSize" className="block mb-2 font-medium">
                  Step Size (h)
                </Label>
                <Input
                  id="stepSize"
                  name="stepSize"
                  type="number"
                  value={formData.stepSize}
                  onChange={handleInputChange}
                  className="w-full"
                  min="0.0001"
                  step="0.01"
                />
              </div>
            </div>
            
            <div className="mb-4">
              <Label htmlFor="method" className="block mb-2 font-medium">
                Differentiation Method
              </Label>
              <Select value={formData.method} onValueChange={handleMethodChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select method" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="forward">Forward Difference O(h)</SelectItem>
                  <SelectItem value="backward">Backward Difference O(h)</SelectItem>
                  <SelectItem value="central">Central Difference O(h²)</SelectItem>
                  <SelectItem value="forward-oh2">Forward Difference O(h²)</SelectItem>
                  <SelectItem value="backward-oh2">Backward Difference O(h²)</SelectItem>
                  <SelectItem value="central-oh4">Central Difference O(h⁴)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button 
              onClick={calculateDerivative} 
              className="w-full mt-2" 
              disabled={isCalculating}
            >
              {isCalculating ? "Calculating..." : "Calculate Derivative"}
            </Button>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-medium mb-3">Differentiation Method Description</h3>
            
            {formData.method === 'forward' && (
              <div>
                <p className="mb-2">The forward difference method approximates the derivative using points ahead of x.</p>
                <Formula formula="f'(x) \approx \frac{f(x+h) - f(x)}{h}" />
                <p className="mt-2">This method has O(h) accuracy - the error is proportional to the step size.</p>
              </div>
            )}
            
            {formData.method === 'backward' && (
              <div>
                <p className="mb-2">The backward difference method approximates the derivative using points behind x.</p>
                <Formula formula="f'(x) \approx \frac{f(x) - f(x-h)}{h}" />
                <p className="mt-2">This method has O(h) accuracy - the error is proportional to the step size.</p>
              </div>
            )}
            
            {formData.method === 'central' && (
              <div>
                <p className="mb-2">The central difference method uses points symmetrically around x.</p>
                <Formula formula="f'(x) \approx \frac{f(x+h) - f(x-h)}{2 \cdot h}" />
                <p className="mt-2">This method has O(h²) accuracy - the error is proportional to the square of the step size, making it more accurate than forward or backward methods.</p>
              </div>
            )}
            
            {formData.method === 'forward-oh2' && (
              <div>
                <p className="mb-2">The higher-order forward difference method uses more points for better accuracy.</p>
                <Formula formula="f'(x) \approx \frac{-f(x+2h) + 4 \cdot f(x+h) - 3 \cdot f(x)}{2 \cdot h}" />
                <p className="mt-2">This method has O(h²) accuracy, significantly better than the standard forward difference.</p>
              </div>
            )}
            
            {formData.method === 'backward-oh2' && (
              <div>
                <p className="mb-2">The higher-order backward difference method uses more points for better accuracy.</p>
                <Formula formula="f'(x) \approx \frac{3 \cdot f(x) - 4 \cdot f(x-h) + f(x-2h)}{2 \cdot h}" />
                <p className="mt-2">This method has O(h²) accuracy, significantly better than the standard backward difference.</p>
              </div>
            )}
            
            {formData.method === 'central-oh4' && (
              <div>
                <p className="mb-2">The high-precision central difference method uses multiple points for exceptional accuracy.</p>
                <Formula formula="f'(x) \approx \frac{-f(x+2h) + 8 \cdot f(x+h) - 8 \cdot f(x-h) + f(x-2h)}{12 \cdot h}" />
                <p className="mt-2">This method has O(h⁴) accuracy, making it extremely precise even with larger step sizes.</p>
              </div>
            )}
          </div>
        </div>
        
        {error && (
          <div className="mb-6 p-4 border border-red-300 bg-red-50 rounded-md text-red-800">
            {error}
          </div>
        )}
        
        {result !== null && (
          <div className="mb-6">
            <h3 className="text-xl font-medium mb-3">Result</h3>
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="text-lg font-medium">
                f'({formData.xValue}) ≈ {result.toFixed(6)}
              </div>
              {exactResult !== null && (
                <div className="mt-2">
                  <div>Exact value: {exactResult.toFixed(6)}</div>
                  <div>Absolute error: {Math.abs(exactResult - result).toFixed(6)}</div>
                  <div>Relative error: {(Math.abs(exactResult - result) / Math.abs(exactResult) * 100).toFixed(4)}%</div>
                </div>
              )}
            </div>
          </div>
        )}
        
        {solutionSteps.length > 0 && (
          <div>
            <h3 className="text-xl font-medium mb-3">Step-by-Step Solution</h3>
            <div className="border border-gray-200 rounded-lg bg-white">
              {solutionSteps.map((step, index) => (
                <div key={index} className={`p-4 ${index < solutionSteps.length - 1 ? 'border-b border-gray-200' : ''}`}>
                  <p className="font-medium mb-2">{step.explanation}</p>
                  {step.formula && <Formula formula={step.formula} />}
                  {step.value && <p className="mt-2">{step.value}</p>}
                </div>
              ))}
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}