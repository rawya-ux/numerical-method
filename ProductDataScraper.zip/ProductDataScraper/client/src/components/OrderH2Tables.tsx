import React from "react";
import DerivativeTable from "./DerivativeTable";

export function ForwardOh2Table() {
  const headers = ["Derivative", "Forward Difference Formula (O(h²))", "Truncation Error"];
  
  const rows = [
    {
      derivative: "First, f'(x)",
      formula: "\\frac{-f(x+2h) + 4f(x+h) - 3f(x)}{2h}",
      error: "O(h²)"
    },
    {
      derivative: "Second, f''(x)",
      formula: "\\frac{-f(x+3h) + 4f(x+2h) - 5f(x+h) + 2f(x)}{h^2}",
      error: "O(h²)"
    },
    {
      derivative: "Third, f'''(x)",
      formula: "\\frac{-3f(x+4h) + 14f(x+3h) - 24f(x+2h) + 18f(x+h) - 5f(x)}{2h^3}",
      error: "O(h²)"
    },
    {
      derivative: "Fourth, f⁽⁴⁾(x)",
      formula: "\\frac{-2f(x+5h) + 11f(x+4h) - 24f(x+3h) + 26f(x+2h) - 14f(x+h) + 3f(x)}{h^4}",
      error: "O(h²)"
    }
  ];
  
  return (
    <DerivativeTable
      title="Forward Difference O(h²) Formulas"
      description="Higher-order accuracy formulas that use additional points for better precision:"
      headers={headers}
      rows={rows}
    />
  );
}

export function BackwardOh2Table() {
  const headers = ["Derivative", "Backward Difference Formula (O(h²))", "Truncation Error"];
  
  const rows = [
    {
      derivative: "First, f'(x)",
      formula: "\\frac{3f(x) - 4f(x-h) + f(x-2h)}{2h}",
      error: "O(h²)"
    },
    {
      derivative: "Second, f''(x)",
      formula: "\\frac{2f(x) - 5f(x-h) + 4f(x-2h) - f(x-3h)}{h^2}",
      error: "O(h²)"
    },
    {
      derivative: "Third, f'''(x)",
      formula: "\\frac{5f(x) - 18f(x-h) + 24f(x-2h) - 14f(x-3h) + 3f(x-4h)}{2h^3}",
      error: "O(h²)"
    },
    {
      derivative: "Fourth, f⁽⁴⁾(x)",
      formula: "\\frac{3f(x) - 14f(x-h) + 26f(x-2h) - 24f(x-3h) + 11f(x-4h) - 2f(x-5h)}{h^4}",
      error: "O(h²)"
    }
  ];
  
  return (
    <DerivativeTable
      title="Backward Difference O(h²) Formulas"
      description="Higher-order accuracy formulas that use additional points for better precision:"
      headers={headers}
      rows={rows}
    />
  );
}

export function CentralOh4Table() {
  const headers = ["Derivative", "Central Difference Formula (O(h⁴))", "Truncation Error"];
  
  const rows = [
    {
      derivative: "First, f'(x)",
      formula: "\\frac{-f(x+2h) + 8f(x+h) - 8f(x-h) + f(x-2h)}{12h}",
      error: "O(h⁴)"
    },
    {
      derivative: "Second, f''(x)",
      formula: "\\frac{-f(x+2h) + 16f(x+h) - 30f(x) + 16f(x-h) - f(x-2h)}{12h^2}",
      error: "O(h⁴)"
    },
    {
      derivative: "Third, f'''(x)",
      formula: "\\frac{-f(x+3h) + 8f(x+2h) - 13f(x+h) + 13f(x-h) - 8f(x-2h) + f(x-3h)}{8h^3}",
      error: "O(h⁴)"
    },
    {
      derivative: "Fourth, f⁽⁴⁾(x)",
      formula: "\\frac{-f(x+3h) + 12f(x+2h) - 39f(x+h) + 56f(x) - 39f(x-h) + 12f(x-2h) - f(x-3h)}{6h^4}",
      error: "O(h⁴)"
    }
  ];
  
  return (
    <DerivativeTable
      title="Central Difference O(h⁴) Formulas"
      description="High-precision formulas with fourth-order accuracy using multiple grid points:"
      headers={headers}
      rows={rows}
    />
  );
}

export default function OrderH2Tables() {
  return (
    <div className="mb-12">
      <h2 className="text-2xl font-semibold font-inter mb-4 text-primary">Higher-Order Accuracy Formulas</h2>
      <p className="mb-6">
        These formulas provide better accuracy than standard O(h) methods by including more terms from the Taylor series.
        They require additional evaluation points but significantly reduce truncation error.
      </p>
      
      <ForwardOh2Table />
      <BackwardOh2Table />
      <CentralOh4Table />
    </div>
  );
}