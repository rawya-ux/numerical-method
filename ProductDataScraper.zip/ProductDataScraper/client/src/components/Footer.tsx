export default function Footer() {
  return (
    <footer className="bg-primary text-white py-6">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h2 className="text-xl font-bold">Numerical Differentiation</h2>
            <p className="text-sm mt-1">Educational Tool for Numerical Methods</p>
          </div>
          <div>
            <p className="text-sm">&copy; {new Date().getFullYear()} Numerical Methods Education</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
