import { useEffect, useRef } from "react";
import useMathJax from "@/hooks/useMathJax";

interface FormulaProps {
  formula: string;
  className?: string;
}

export default function Formula({ formula, className = "" }: FormulaProps) {
  const formulaRef = useRef<HTMLDivElement>(null);
  const { renderMath } = useMathJax();

  useEffect(() => {
    if (formulaRef.current) {
      renderMath(formulaRef.current);
    }
  }, [formula, renderMath]);

  const defaultClass = "formula-display mathjax-process";
  const combinedClass = className ? `${defaultClass} ${className}` : defaultClass;

  return (
    <div className={combinedClass} ref={formulaRef}>
      {`\\[ ${formula} \\]`}
    </div>
  );
}
