import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

interface TutorialSolutionProps {
  title: string;
  children: React.ReactNode;
}

export default function TutorialSolution({ title, children }: TutorialSolutionProps) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleSolution = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="mt-4">
      <div className="border border-gray-200 rounded-lg bg-white">
        <div className="bg-primary/5 p-3 flex items-center justify-between border-b border-gray-200">
          <span className="font-medium">{title}</span>
          <button 
            onClick={toggleSolution}
            className="text-primary hover:text-primary-dark flex items-center"
          >
            {isOpen ? (
              <>Hide Solution <ChevronUp className="ml-1 h-4 w-4" /></>
            ) : (
              <>Show Solution <ChevronDown className="ml-1 h-4 w-4" /></>
            )}
          </button>
        </div>
        <div className={`p-4 space-y-4 ${isOpen ? "" : "hidden"}`}>
          {children}
        </div>
      </div>
    </div>
  );
}
