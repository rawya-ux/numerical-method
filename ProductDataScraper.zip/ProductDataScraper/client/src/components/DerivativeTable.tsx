import { useEffect, useRef } from "react";
import useMathJax from "@/hooks/useMathJax";

interface TableRow {
  derivative: string;
  formula: string;
  error: string;
}

interface DerivativeTableProps {
  headers: string[];
  rows: TableRow[];
  title?: string;
  description?: string;
}

export default function DerivativeTable({ 
  headers, 
  rows, 
  title,
  description 
}: DerivativeTableProps) {
  const { renderMath } = useMathJax();
  const tableRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (tableRef.current) {
      renderMath(tableRef.current);
    }
  }, [renderMath, rows]);

  return (
    <div className="mb-8">
      {title && <h3 className="text-xl font-medium mb-2">{title}</h3>}
      {description && <p className="mb-4">{description}</p>}
      
      <div ref={tableRef} className="overflow-x-auto">
        <table className="derivative-table w-full border-collapse">
          <thead>
            <tr className="bg-gray-100">
              {headers.map((header, index) => (
                <th key={index}>{header}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, index) => (
              <tr key={index}>
                <td>{row.derivative}</td>
                <td>
                  <div className="formula-display p-1 my-1 text-base">
                    {`\\( ${row.formula} \\)`}
                  </div>
                </td>
                <td>{row.error}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
