import { Link, useLocation } from "wouter";

export default function Navbar() {
  const [location] = useLocation();

  const isActive = (path: string) => {
    return location === path ? "bg-white/10" : "hover:bg-white/20";
  };

  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center">
        <h1 className="text-2xl font-bold font-inter mb-2 md:mb-0">Numerical Differentiation</h1>
        <nav>
          <ul className="flex space-x-1 md:space-x-4 text-sm md:text-base overflow-x-auto pb-2 md:pb-0">
            <li>
              <Link href="/">
                <span className={`px-2 py-1 rounded transition-colors duration-200 ${isActive("/")} cursor-pointer inline-block`}>
                  Home
                </span>
              </Link>
            </li>
            <li>
              <Link href="/forward">
                <span className={`px-2 py-1 rounded transition-colors duration-200 ${isActive("/forward")} cursor-pointer inline-block`}>
                  Forward
                </span>
              </Link>
            </li>
            <li>
              <Link href="/backward">
                <span className={`px-2 py-1 rounded transition-colors duration-200 ${isActive("/backward")} cursor-pointer inline-block`}>
                  Backward
                </span>
              </Link>
            </li>
            <li>
              <Link href="/central">
                <span className={`px-2 py-1 rounded transition-colors duration-200 ${isActive("/central")} cursor-pointer inline-block`}>
                  Central
                </span>
              </Link>
            </li>
            <li>
              <Link href="/richardson">
                <span className={`px-2 py-1 rounded transition-colors duration-200 ${isActive("/richardson")} cursor-pointer inline-block`}>
                  Richardson
                </span>
              </Link>
            </li>
            <li>
              <Link href="/higher-order">
                <span className={`px-2 py-1 rounded transition-colors duration-200 ${isActive("/higher-order")} cursor-pointer inline-block`}>
                  Higher-Order
                </span>
              </Link>
            </li>
            <li>
              <Link href="/solver">
                <span className={`px-2 py-1 rounded transition-colors duration-200 ${isActive("/solver")} cursor-pointer inline-block`}>
                  Solver
                </span>
              </Link>
            </li>
            <li>
              <Link href="/tutorial">
                <span className={`px-2 py-1 rounded transition-colors duration-200 ${isActive("/tutorial")} cursor-pointer inline-block`}>
                  Tutorial
                </span>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
