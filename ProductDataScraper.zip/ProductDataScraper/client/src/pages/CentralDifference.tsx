import { useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import Formula from "@/components/Formula";
import useMathJax from "@/hooks/useMathJax";

export default function CentralDifference() {
  const pageRef = useRef<HTMLDivElement>(null);
  const { renderMath } = useMathJax();

  useEffect(() => {
    if (pageRef.current) {
      renderMath(pageRef.current);
    }
  }, [renderMath]);
  
  return (
    <section ref={pageRef} className="mb-12">
      <Card className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold font-inter mb-4 text-primary">Central Difference Method</h2>
        
        <div className="mb-6">
          <h3 className="text-xl font-medium mb-3">Theoretical Foundation</h3>
          <p className="mb-4">
            The central difference method approximates derivatives using symmetric points around the point of interest. It offers better accuracy than forward or backward methods with the same step size.
          </p>
          
          <p className="mb-4">Starting with the Taylor series expansions for f(x+h) and f(x-h):</p>
          
          <Formula formula="f(x+h) = f(x) + f'(x)h + \frac{f''(x)h^2}{2!} + \frac{f'''(x)h^3}{3!} + \frac{f^{(4)}(x)h^4}{4!} + \cdots" />
          
          <Formula formula="f(x-h) = f(x) - f'(x)h + \frac{f''(x)h^2}{2!} - \frac{f'''(x)h^3}{3!} + \frac{f^{(4)}(x)h^4}{4!} - \cdots" />
          
          <p className="my-4">Subtracting the second equation from the first:</p>
          
          <Formula formula="f(x+h) - f(x-h) = 2f'(x)h + 2\frac{f'''(x)h^3}{3!} + \cdots" />
          
          <p className="my-4">Solving for f'(x):</p>
          
          <Formula formula="f'(x) = \frac{f(x+h) - f(x-h)}{2h} - \frac{f'''(x)h^2}{3!} - \cdots" />
          
          <p className="mt-4">This gives us the second-order central difference approximation:</p>
          
          <Formula 
            formula="f'(x) \approx \frac{f(x+h) - f(x-h)}{2h} + O(h^2)" 
            className="bg-secondary/5 border-l-4 border-secondary"
          />
          
          <p className="mt-4 text-green-700 font-medium">Note: The central difference method has O(h²) truncation error, making it more accurate than the O(h) error in forward and backward methods.</p>
        </div>
        
        <div className="mb-6">
          <h3 className="text-xl font-medium mb-3">Formula Table for Higher Order Derivatives</h3>
          <div className="overflow-x-auto">
            <table className="derivative-table w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th>Derivative</th>
                  <th>Central Difference Formula</th>
                  <th>Truncation Error</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>First, f'(x)</td>
                  <td>{`\\( \\frac{f(x+h) - f(x-h)}{2h} \\)`}</td>
                  <td>O(h²)</td>
                </tr>
                <tr>
                  <td>Second, f''(x)</td>
                  <td>{`\\( \\frac{f(x+h) - 2 \\cdot f(x) + f(x-h)}{h^2} \\)`}</td>
                  <td>O(h²)</td>
                </tr>
                <tr>
                  <td>Third, f'''(x)</td>
                  <td>{`\\( \\frac{f(x+2h) - 2 \\cdot f(x+h) + 2 \\cdot f(x-h) - f(x-2h)}{2h^3} \\)`}</td>
                  <td>O(h²)</td>
                </tr>
                <tr>
                  <td>Fourth, f⁽⁴⁾(x)</td>
                  <td>{`\\( \\frac{f(x+2h) - 4 \\cdot f(x+h) + 6 \\cdot f(x) - 4 \\cdot f(x-h) + f(x-2h)}{h^4} \\)`}</td>
                  <td>O(h²)</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        {/* Example - Rocket Velocity with Central Difference */}
        <div className="mt-8">
          <h3 className="text-xl font-medium mb-3">Example: Rocket Velocity using Central Difference</h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="font-medium">Using the same rocket velocity function:</p>
            <Formula formula="v(t) = 2000 \ln\left(\frac{14 \cdot 10^4}{14 \cdot 10^4 - 2100t}\right) - 9.8t, \quad 0 \leq t \leq 30" />
            
            <p className="mt-4">Calculate the acceleration at t = 16s using central difference with a step size of h = 2s.</p>
            
            {/* Interactive Step Solution */}
            <div className="mt-4">
              <div className="border border-gray-200 rounded-lg bg-white">
                <div className="bg-primary/5 p-3 font-medium border-b border-gray-200">
                  Step-by-Step Solution
                </div>
                <div className="p-4 space-y-3">
                  <div>
                    <p className="font-medium">Step 1: Apply the central difference formula for the first derivative</p>
                    <Formula formula="a(16) = v'(16) \approx \frac{v(16+2) - v(16-2)}{2 \cdot 2} = \frac{v(18) - v(14)}{4}" />
                  </div>
                  
                  <div>
                    <p className="font-medium">Step 2: Calculate v(14)</p>
                    <Formula formula="v(14) = 2000 \ln\left(\frac{14 \cdot 10^4}{14 \cdot 10^4 - 2100 \cdot 14}\right) - 9.8 \cdot 14" />
                    <Formula formula="v(14) = 334.24 \text{ m/s}" />
                  </div>
                  
                  <div>
                    <p className="font-medium">Step 3: Calculate v(18)</p>
                    <Formula formula="v(18) = 2000 \ln\left(\frac{14 \cdot 10^4}{14 \cdot 10^4 - 2100 \cdot 18}\right) - 9.8 \cdot 18" />
                    <Formula formula="v(18) = 453.02 \text{ m/s}" />
                  </div>
                  
                  <div>
                    <p className="font-medium">Step 4: Calculate the approximation of acceleration</p>
                    <Formula formula="a(16) \approx \frac{453.02 - 334.24}{4} = \frac{118.78}{4} = 29.695 \text{ m/s}^2" />
                  </div>
                  
                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                    <p className="font-medium text-primary">Analytical Solution for Comparison:</p>
                    <Formula formula="a(t) = \frac{d}{dt}v(t) = \frac{4.2 \cdot 10^6}{(14 \cdot 10^4 - 2100t)} - 9.8" />
                    <div>Evaluating at t = 16:</div>
                    <Formula formula="a(16) = 29.674 \text{ m/s}^2" />
                    <div>Absolute relative true error = 0.071%</div>
                    <div className="text-green-700 font-medium mt-2">The central difference method gives a more accurate result than the forward or backward methods with the same step size.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Error Analysis Section */}
        <div className="mt-8">
          <h3 className="text-xl font-medium mb-3">Error Analysis and Step Size Effect</h3>
          <div className="mb-2">
            <span>For the function </span>
            <Formula formula="f(x) = 9e^{4x}" />
            <span>, we can analyze how the step size affects the accuracy of the central difference method:</span>
          </div>
          
          <div className="overflow-x-auto mt-4">
            <table className="derivative-table w-full border-collapse text-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th>Step Size (h)</th>
                  <th>Approximation f'(0.2)</th>
                  <th>Absolute Error</th>
                  <th>Relative Error (%)</th>
                  <th>Significant Digits</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>0.05</td>
                  <td>80.655</td>
                  <td>0.535</td>
                  <td>0.668</td>
                  <td>1</td>
                </tr>
                <tr>
                  <td>0.025</td>
                  <td>80.253</td>
                  <td>0.134</td>
                  <td>0.167</td>
                  <td>2</td>
                </tr>
                <tr>
                  <td>0.0125</td>
                  <td>80.153</td>
                  <td>0.033</td>
                  <td>0.042</td>
                  <td>3</td>
                </tr>
                <tr>
                  <td>0.00625</td>
                  <td>80.128</td>
                  <td>0.008</td>
                  <td>0.010</td>
                  <td>3</td>
                </tr>
                <tr>
                  <td>0.003125</td>
                  <td>80.122</td>
                  <td>0.002</td>
                  <td>0.003</td>
                  <td>4</td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-4 rounded-lg border border-gray-200">
              <h4 className="font-medium mb-2">Error Analysis</h4>
              <ul className="list-disc pl-5 space-y-2">
                <li>As step size decreases, the error decreases quadratically (O(h²))</li>
                <li>Each halving of the step size reduces the error by approximately a factor of 4</li>
                <li>Significant digits increase as step size decreases</li>
                <li>Very small step sizes may introduce roundoff errors</li>
              </ul>
            </div>
            
            <div className="bg-white p-4 rounded-lg border border-gray-200">
              <h4 className="font-medium mb-2">Convergence Characteristics</h4>
              <ul className="list-disc pl-5 space-y-2">
                <li>Central difference converges faster than forward/backward methods</li>
                <li>The method is symmetric around the evaluation point</li>
                <li>Requires function evaluations at both x+h and x-h</li>
                <li>Cannot be used at boundary points without additional data</li>
                <li>Optimal for interior points when data is available on both sides</li>
              </ul>
            </div>
          </div>
        </div>
      </Card>
    </section>
  );
}
