import { useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import Formula from "@/components/Formula";
import useMathJax from "@/hooks/useMathJax";

export default function RichardsonExtrapolation() {
  const pageRef = useRef<HTMLDivElement>(null);
  const { renderMath } = useMathJax();

  useEffect(() => {
    if (pageRef.current) {
      renderMath(pageRef.current);
    }
  }, [renderMath]);
  
  return (
    <section ref={pageRef} className="mb-12">
      <Card className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold font-inter mb-4 text-primary">Richardson Extrapolation</h2>
        
        <div className="mb-6">
          <h3 className="text-xl font-medium mb-3">Theory and Purpose</h3>
          <p className="mb-4">
            Richardson extrapolation is a sequence acceleration method used to improve the accuracy of numerical differentiation. It combines approximations at different step sizes to cancel out leading error terms.
          </p>
          
          <p className="mb-4">
            If we know the error in a numerical method is of the form:
          </p>
          
          <Formula formula="F(h) = F + \alpha h^n + \beta h^{n+1} + \cdots" />
          
          <p className="mb-3">Where:</p>
          <ul className="list-disc pl-8 mb-4">
            <li>F is the exact value we seek</li>
            <li>F(h) is our approximation with step size h</li>
            <li>α, β are unknown coefficients</li>
            <li>n is the order of the error</li>
          </ul>
          
          <p className="mb-4">
            By computing F(h) and F(h/2) and combining them appropriately, we can eliminate the leading error term:
          </p>
          
          <Formula 
            formula="F_{\text{improved}} = \frac{2^n \cdot F(h/2) - F(h)}{2^n - 1}" 
            className="bg-secondary/5 border-l-4 border-secondary"
          />
          
          <p className="mt-4">
            For central difference approximations of first derivatives (n=2):
          </p>
          
          <Formula formula="F_{\text{improved}} = \frac{4 \cdot F(h/2) - F(h)}{3}" />
        </div>
        
        <div className="mb-6">
          <h3 className="text-xl font-medium mb-3">Implementation of Richardson Extrapolation</h3>
          
          <div className="bg-gray-50 p-4 rounded-lg mb-4">
            <h4 className="font-medium mb-2">Algorithm:</h4>
            <ol className="list-decimal pl-8 space-y-2">
              <li>Select an initial step size h and compute F(h)</li>
              <li>Compute F(h/2) using half the step size</li>
              <li>Apply the Richardson formula based on the order of error</li>
              <li>Optionally, repeat with smaller step sizes to create higher-order approximations</li>
            </ol>
          </div>
          
          <div className="overflow-x-auto">
            <table className="derivative-table w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th>Method</th>
                  <th>Error Order</th>
                  <th>Richardson Formula</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Forward/Backward Difference (1st derivative)</td>
                  <td>O(h)</td>
                  <td>{`\\( \\frac{2 \\cdot F(h/2) - F(h)}{1} \\)`}</td>
                </tr>
                <tr>
                  <td>Central Difference (1st derivative)</td>
                  <td>O(h²)</td>
                  <td>{`\\( \\frac{4 \\cdot F(h/2) - F(h)}{3} \\)`}</td>
                </tr>
                <tr>
                  <td>Central Difference (2nd derivative)</td>
                  <td>O(h²)</td>
                  <td>{`\\( \\frac{4 \\cdot F(h/2) - F(h)}{3} \\)`}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        {/* Example Problem */}
        <div className="mt-8">
          <h3 className="text-xl font-medium mb-3">Example Problem</h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="mb-2">
              <span className="font-medium">Consider again the function </span>
              <Formula formula="f(x) = 9e^{4x}" />
              <span> at x = 0.2</span>
            </div>
            <p className="mt-2">Apply Richardson extrapolation to improve the central difference approximation of f'(0.2)</p>
            
            {/* Interactive Step Solution */}
            <div className="mt-4">
              <div className="border border-gray-200 rounded-lg bg-white">
                <div className="bg-primary/5 p-3 font-medium border-b border-gray-200">
                  Step-by-Step Solution
                </div>
                <div className="p-4 space-y-3">
                  <div>
                    <p className="font-medium">Step 1: Calculate the central difference approximation with h = 0.05</p>
                    <Formula formula="F(0.05) = \frac{f(0.25) - f(0.15)}{2 \cdot 0.05} = \frac{24.5614 - 16.3989}{0.1} = 80.6547" />
                  </div>
                  
                  <div>
                    <p className="font-medium">Step 2: Calculate the central difference approximation with h = 0.025</p>
                    <Formula formula="F(0.025) = \frac{f(0.225) - f(0.175)}{2 \cdot 0.025} = \frac{22.1901 - 18.1778}{0.05} = 80.2531" />
                  </div>
                  
                  <div>
                    <p className="font-medium">Step 3: Apply the Richardson extrapolation formula (n=2 for central difference)</p>
                    <Formula formula="F_{\text{improved}} = \frac{4 \cdot 80.2531 - 80.6547}{3} = \frac{320.1023 - 80.6547}{3} = 79.8159" />
                  </div>
                  
                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                    <p className="font-medium text-primary">Comparison with Analytical Solution:</p>
                    <Formula formula="f'(0.2) = 36 \cdot 9e^{4 \cdot 0.2} = 80.1180" />
                    <div>Central Difference (h=0.05) Error: 0.6680%</div>
                    <div>Central Difference (h=0.025) Error: 0.1668%</div>
                    <div>Richardson Improved Error: 0.3770%</div>
                  </div>
                  
                  <div className="bg-green-50 p-3 rounded-lg border border-green-100 mt-4">
                    <p className="font-medium text-green-800">Iterative Richardson Extrapolation</p>
                    <p>We can create a Richardson extrapolation table by continuing to halve the step size:</p>
                    <div className="overflow-x-auto mt-2">
                      <table className="derivative-table w-full border-collapse text-sm">
                        <thead>
                          <tr className="bg-gray-100">
                            <th>Step Size (h)</th>
                            <th>D₁ (Raw)</th>
                            <th>D₂ (1st Richardson)</th>
                            <th>D₃ (2nd Richardson)</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>0.05</td>
                            <td>80.6547</td>
                            <td>-</td>
                            <td>-</td>
                          </tr>
                          <tr>
                            <td>0.025</td>
                            <td>80.2531</td>
                            <td>80.1190</td>
                            <td>-</td>
                          </tr>
                          <tr>
                            <td>0.0125</td>
                            <td>80.1529</td>
                            <td>80.1195</td>
                            <td>80.1197</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    <p className="mt-2">Notice how the extrapolated values converge more rapidly to the true value of 80.1180.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </section>
  );
}
