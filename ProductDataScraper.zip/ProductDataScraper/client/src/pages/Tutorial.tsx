import { useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import Formula from "@/components/Formula";
import TutorialSolution from "@/components/TutorialSolution";
import useMathJax from "@/hooks/useMathJax";

export default function Tutorial() {
  const pageRef = useRef<HTMLDivElement>(null);
  const { renderMath } = useMathJax();

  useEffect(() => {
    if (pageRef.current) {
      renderMath(pageRef.current);
    }
  }, [renderMath]);
  
  return (
    <section ref={pageRef} className="mb-12">
      <Card className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold font-inter mb-4 text-primary">Tutorial: Step-by-Step Problem Solving</h2>
        
        <div className="mb-8">
          <h3 className="text-xl font-medium mb-3">Problem 1: Rocket Acceleration</h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="font-medium">The velocity of a rocket is given by:</p>
            <Formula formula="v(t) = 2000 \ln\left(\frac{14 \cdot 10^4}{14 \cdot 10^4 - 2100 \cdot t}\right) - 9.8 \cdot t, \quad 0 \leq t \leq 30" />
            
            <p className="mt-4">Calculate the acceleration at t = 20s using all three methods (forward, backward, and central) with a step size of h = 1s. Compare with the analytical solution.</p>
            
            <TutorialSolution title="Interactive Solution">
              <p className="font-medium">First, let's calculate the function values we need:</p>
              
              <div className="overflow-x-auto">
                <table className="derivative-table w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-100">
                      <th>t</th>
                      <th>v(t) in m/s</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>19</td>
                      <td>491.76</td>
                    </tr>
                    <tr>
                      <td>20</td>
                      <td>524.31</td>
                    </tr>
                    <tr>
                      <td>21</td>
                      <td>559.28</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              
              <p className="font-medium mt-4">Forward Difference Method:</p>
              <Formula formula="a(20) \approx \frac{v(21) - v(20)}{1} = \frac{559.28 - 524.31}{1} = 34.97 \text{ m/s}^2" />
              
              <p className="font-medium mt-4">Backward Difference Method:</p>
              <Formula formula="a(20) \approx \frac{v(20) - v(19)}{1} = \frac{524.31 - 491.76}{1} = 32.55 \text{ m/s}^2" />
              
              <p className="font-medium mt-4">Central Difference Method:</p>
              <Formula formula="a(20) \approx \frac{v(21) - v(19)}{2 \cdot 1} = \frac{559.28 - 491.76}{2} = 33.76 \text{ m/s}^2" />
              
              <p className="font-medium mt-4">Analytical Solution:</p>
              <Formula formula="a(t) = \frac{d}{dt}v(t) = \frac{4.2 \cdot 10^6}{(14 \cdot 10^4 - 2100 \cdot t)} - 9.8" />
              <Formula formula="a(20) = 33.77 \text{ m/s}^2" />
              
              <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 mt-4">
                <p className="font-medium">Error Analysis:</p>
                <ul className="list-disc pl-8 space-y-1">
                  <li>Forward Difference Error: 3.55%</li>
                  <li>Backward Difference Error: 3.61%</li>
                  <li>Central Difference Error: 0.03%</li>
                </ul>
                <p className="mt-2">The central difference method provides the most accurate approximation in this case.</p>
              </div>
            </TutorialSolution>
          </div>
        </div>
        
        <div className="mb-8">
          <h3 className="text-xl font-medium mb-3">Problem 2: Error Analysis with Variable Step Size</h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="font-medium">For the function <Formula formula="f(x) = 9e^{4x}" />, investigate how the error in the central difference approximation of f'(0.2) changes as the step size decreases.</div>
            
            <p className="mt-4">Calculate the approximation using step sizes h = 0.1, 0.05, 0.025, and 0.0125. Compare with the analytical derivative and analyze the convergence rate.</p>
            
            <TutorialSolution title="Interactive Solution">
              <p className="font-medium">First, we know the analytical derivative:</p>
              <Formula formula="f'(x) = 36 \cdot e^{4x}" />
              <p>At x = 0.2:</p>
              <Formula formula="f'(0.2) = 36 \cdot e^{4 \cdot 0.2} = 36 \cdot e^{0.8} = 36 \cdot 2.2255 = 80.118" />
              
              <p className="font-medium mt-4">Central difference approximations:</p>
              
              <div className="overflow-x-auto">
                <table className="derivative-table w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-100">
                      <th>Step Size (h)</th>
                      <th>Approximation</th>
                      <th>Absolute Error</th>
                      <th>Relative Error (%)</th>
                      <th>Error Reduction</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>0.1</td>
                      <td>81.71</td>
                      <td>1.592</td>
                      <td>1.988</td>
                      <td>-</td>
                    </tr>
                    <tr>
                      <td>0.05</td>
                      <td>80.65</td>
                      <td>0.532</td>
                      <td>0.664</td>
                      <td>2.99×</td>
                    </tr>
                    <tr>
                      <td>0.025</td>
                      <td>80.25</td>
                      <td>0.132</td>
                      <td>0.165</td>
                      <td>4.03×</td>
                    </tr>
                    <tr>
                      <td>0.0125</td>
                      <td>80.15</td>
                      <td>0.032</td>
                      <td>0.040</td>
                      <td>4.13×</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              
              <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 mt-4">
                <p className="font-medium">Analysis:</p>
                <ul className="list-disc pl-8 space-y-1">
                  <li>The error reduces by approximately a factor of 4 each time h is halved</li>
                  <li>This confirms the O(h²) error behavior of the central difference method</li>
                  <li>The convergence rate is approximately 2, as expected for a second-order method</li>
                  <li>We can calculate the convergence rate as: p ≈ log(E₁/E₂)/log(h₁/h₂) ≈ 2</li>
                </ul>
              </div>
            </TutorialSolution>
          </div>
        </div>
        
        <div className="mb-8">
          <h3 className="text-xl font-medium mb-3">Problem 3: Richardson Extrapolation Application</h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="font-medium">For the function <Formula formula="f(x) = x^2 \sin(x)" />, use Richardson extrapolation to improve the forward difference approximation of f'(π/4).</div>
            
            <TutorialSolution title="Interactive Solution">
              <p className="font-medium">First, we calculate the function values:</p>
              <Formula formula="f(\pi/4) = (\pi/4)^2 \cdot \sin(\pi/4) = (\pi/4)^2 \cdot (1/\sqrt{2}) = (\pi^2/16) \cdot (1/\sqrt{2}) \approx 0.1947" />
              <Formula formula="f(\pi/4 + 0.1) \approx 0.2603" />
              <Formula formula="f(\pi/4 + 0.05) \approx 0.2271" />
              
              <p className="font-medium mt-4">Forward difference with h = 0.1:</p>
              <Formula formula="F(0.1) = \frac{f(\pi/4 + 0.1) - f(\pi/4)}{0.1} = \frac{0.2603 - 0.1947}{0.1} = 0.6560" />
              
              <p className="font-medium mt-4">Forward difference with h = 0.05:</p>
              <Formula formula="F(0.05) = \frac{f(\pi/4 + 0.05) - f(\pi/4)}{0.05} = \frac{0.2271 - 0.1947}{0.05} = 0.6480" />
              
              <p className="font-medium mt-4">Richardson extrapolation (n=1 for forward difference):</p>
              <Formula formula="F_{improved} = \frac{2 \cdot 0.6480 - 0.6560}{2 - 1} = \frac{1.2960 - 0.6560}{1} = 0.6400" />
              
              <p className="font-medium mt-4">Analytical derivative:</p>
              <Formula formula="f'(x) = 2x \cdot \sin(x) + x^2 \cdot \cos(x)" />
              <p>At x = π/4:</p>
              <Formula formula="f'(\pi/4) = 2(\pi/4) \cdot \sin(\pi/4) + (\pi/4)^2 \cdot \cos(\pi/4)" />
              <Formula formula="= 2(\pi/4) \cdot (1/\sqrt{2}) + (\pi/4)^2 \cdot (1/\sqrt{2})" />
              <Formula formula="= (1/\sqrt{2})[(2\pi/4) + (\pi/4)^2] \approx 0.6366" />
              
              <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 mt-4">
                <p className="font-medium">Error Analysis:</p>
                <ul className="list-disc pl-8 space-y-1">
                  <li>Forward Difference (h=0.1) Error: 3.05%</li>
                  <li>Forward Difference (h=0.05) Error: 1.79%</li>
                  <li>Richardson Improved Error: 0.53%</li>
                </ul>
                <p className="mt-2">Richardson extrapolation significantly improved the accuracy of the approximation.</p>
              </div>
            </TutorialSolution>
          </div>
        </div>
      </Card>
    </section>
  );
}
