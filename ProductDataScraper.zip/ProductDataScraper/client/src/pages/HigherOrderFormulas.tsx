import { useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import OrderH2Tables from "@/components/OrderH2Tables";
import Formula from "@/components/Formula";
import useMathJax from "@/hooks/useMathJax";

export default function HigherOrderFormulas() {
  const pageRef = useRef<HTMLDivElement>(null);
  const { renderMath } = useMathJax();

  useEffect(() => {
    if (pageRef.current) {
      renderMath(pageRef.current);
    }
  }, [renderMath]);
  
  return (
    <section ref={pageRef} className="mb-12">
      <Card className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold font-inter mb-4 text-primary">Higher-Order Accuracy Formulas</h2>
        
        <div className="mb-6">
          <h3 className="text-xl font-medium mb-3">Introduction to Higher-Order Methods</h3>
          <p className="mb-4">
            Higher-order methods achieve better accuracy by incorporating more terms from the Taylor series expansion.
            By using additional grid points, these methods reduce truncation error from O(h) to O(h²) or even O(h⁴) for central difference methods.
          </p>
          
          <div className="bg-blue-50/50 p-5 rounded-lg mb-6">
            <h4 className="font-medium mb-2">Key Advantages</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>Significantly improved accuracy with the same step size</li>
              <li>Reduced computational cost when high precision is required</li>
              <li>Better stability for certain classes of problems</li>
              <li>More reliable results for sensitive calculations</li>
            </ul>
          </div>
          
          <p className="mb-4">
            The derivation of higher-order formulas involves taking linear combinations of Taylor series expansions
            to eliminate lower-order error terms. For example, to derive a second-order accurate formula for the first derivative:
          </p>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="font-medium">Taylor expansions:</p>
            <Formula formula="f(x+h) = f(x) + f'(x) \cdot h + \frac{f''(x) \cdot h^2}{2!} + \frac{f'''(x) \cdot h^3}{3!} + O(h^4)" />
            <Formula formula="f(x+2h) = f(x) + f'(x) \cdot (2h) + \frac{f''(x) \cdot (2h)^2}{2!} + \frac{f'''(x) \cdot (2h)^3}{3!} + O(h^4)" />
            
            <p className="mt-4 font-medium">Multiply first equation by 4 and subtract second equation:</p>
            <Formula formula="4 \cdot f(x+h) - f(x+2h) = 4 \cdot f(x) + 4 \cdot f'(x) \cdot h + \frac{4 \cdot f''(x) \cdot h^2}{2!} + \frac{4 \cdot f'''(x) \cdot h^3}{3!} - f(x) - f'(x) \cdot (2h) - \frac{f''(x) \cdot (2h)^2}{2!} - \frac{f'''(x) \cdot (2h)^3}{3!} + O(h^4)" />
            
            <p className="mt-4 font-medium">Simplify and solve for f'(x):</p>
            <Formula formula="4 \cdot f(x+h) - f(x+2h) = 3 \cdot f(x) + 4 \cdot f'(x) \cdot h - 2 \cdot f'(x) \cdot h + f''(x) \cdot h^2 - 2 \cdot f''(x) \cdot h^2 + \frac{f'''(x) \cdot h^3}{3} - \frac{8 \cdot f'''(x) \cdot h^3}{3} + O(h^4)" />
            <Formula formula="4 \cdot f(x+h) - f(x+2h) - 3 \cdot f(x) = 2 \cdot f'(x) \cdot h - f''(x) \cdot h^2 - \frac{7 \cdot f'''(x) \cdot h^3}{3} + O(h^4)" />
            <Formula formula="f'(x) = \frac{-f(x+2h) + 4 \cdot f(x+h) - 3 \cdot f(x)}{2h} + O(h^2)" />
          </div>
        </div>
        
        <OrderH2Tables />
        
        <div className="mt-8">
          <h3 className="text-xl font-medium mb-3">Practical Considerations</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-4 rounded-lg border border-gray-200">
              <h4 className="font-medium mb-2">When to Use Higher-Order Formulas</h4>
              <ul className="list-disc pl-5 space-y-1">
                <li>When high accuracy is critical to the application</li>
                <li>When computational resources allow for additional function evaluations</li>
                <li>For smooth functions where higher derivatives exist</li>
                <li>When working with well-conditioned problems</li>
                <li>When stability is more important than simplicity</li>
              </ul>
            </div>
            
            <div className="bg-white p-4 rounded-lg border border-gray-200">
              <h4 className="font-medium mb-2">Limitations to Consider</h4>
              <ul className="list-disc pl-5 space-y-1">
                <li>Requires more function evaluations at different points</li>
                <li>More complex to implement and debug</li>
                <li>May not improve results for noisy or discontinuous data</li>
                <li>Can be sensitive to roundoff errors with very small step sizes</li>
                <li>Boundary points require special treatment or different formulas</li>
              </ul>
            </div>
          </div>
        </div>
      </Card>
    </section>
  );
}
