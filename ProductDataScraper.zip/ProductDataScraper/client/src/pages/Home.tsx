import { useEffect } from "react";
import { Card } from "@/components/ui/card";
import FormulaCard from "@/components/FormulaCard";
import useMathJax from "@/hooks/useMathJax";

export default function Home() {
  const { renderMath } = useMathJax();

  useEffect(() => {
    // Render math when component mounts
    renderMath(document.body);
  }, [renderMath]);

  return (
    <section id="home" className="mb-12">
      <Card className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold font-inter mb-4 text-primary">Introduction to Numerical Differentiation</h2>
        <p className="mb-4">
          Numerical differentiation is the process of finding the numerical value of a derivative of a given function at a particular point. This approach is especially useful when the analytical derivative is difficult or impossible to obtain.
        </p>
        <p className="mb-4">
          Numerous laws involving the spatial behavior of variables are expressed in terms of derivatives. Numerical differentiation methods are essential tools in scientific computing, engineering analysis, and mathematical modeling.
        </p>
        
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <FormulaCard 
            title="Forward Difference"
            formula="f'(x) \approx \frac{f(x+h) - f(x)}{h}"
            description="Approximates the derivative using function values ahead of the point of interest."
            link="/forward"
          />
          
          <FormulaCard 
            title="Backward Difference"
            formula="f'(x) \approx \frac{f(x) - f(x-h)}{h}"
            description="Approximates the derivative using function values before the point of interest."
            link="/backward"
          />
          
          <FormulaCard 
            title="Central Difference"
            formula="f'(x) \approx \frac{f(x+h) - f(x-h)}{2h}"
            description="More accurate method using symmetrical points around the point of interest."
            link="/central"
          />

          <FormulaCard 
            title="Higher-Order Formulas"
            formula="f'(x) \approx \frac{-f(x+2h) + 8 \cdot f(x+h) - 8 \cdot f(x-h) + f(x-2h)}{12h}"
            description="Advanced formulas with improved accuracy (O(h²) and O(h⁴)) using additional grid points."
            link="/higher-order"
          />
          
          <FormulaCard 
            title="Interactive Solver"
            formula="f'(x) \approx \lim_{h \to 0} \frac{f(x+h) - f(x)}{h}"
            description="Calculate derivatives for any function using different methods with step-by-step solutions."
            link="/solver"
          />
        </div>

        <div className="mt-8 bg-blue-50 p-6 rounded-lg border border-blue-100">
          <h3 className="text-lg font-semibold text-primary mb-3">Why Numerical Differentiation?</h3>
          <ul className="list-disc pl-5 space-y-2">
            <li>Analytical derivatives may be complex or impossible to compute</li>
            <li>Real-world data often exists only as discrete points</li>
            <li>Provides practical approximations for engineering applications</li>
            <li>Can be efficiently implemented in computational workflows</li>
            <li>Different methods offer tradeoffs between accuracy and computational cost</li>
          </ul>
        </div>
      </Card>
    </section>
  );
}
