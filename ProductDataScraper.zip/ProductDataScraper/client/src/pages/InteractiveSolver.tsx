import { useEffect, useRef } from "react";
import DerivativeSolver from "@/components/DerivativeSolver";
import useMathJax from "@/hooks/useMathJax";

export default function InteractiveSolver() {
  const pageRef = useRef<HTMLDivElement>(null);
  const { renderMath } = useMathJax();

  useEffect(() => {
    if (pageRef.current) {
      renderMath(pageRef.current);
    }
  }, [renderMath]);
  
  return (
    <section ref={pageRef} className="mb-12">
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h1 className="text-3xl font-semibold font-inter mb-2 text-primary">Interactive Derivative Solver</h1>
        <p className="mb-6 text-gray-700">
          This interactive solver allows you to calculate numerical derivatives using various methods.
          Enter any function, select a point of evaluation, step size, and differentiation method to see a
          step-by-step solution.
        </p>
      </div>
      
      <DerivativeSolver />
      
      <div className="bg-white rounded-lg shadow-md p-6 mt-8">
        <h2 className="text-xl font-semibold font-inter mb-4 text-primary">Usage Guide</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium mb-2">Function Input Tips</h3>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li>Use <code>x</code> as the variable (e.g., <code>x^2 + 3*x - 1</code>)</li>
              <li>Basic operators: <code>+</code>, <code>-</code>, <code>*</code>, <code>/</code>, <code>^</code> (power)</li>
              <li>Functions: <code>sin(x)</code>, <code>cos(x)</code>, <code>tan(x)</code>, <code>exp(x)</code>, <code>log(x)</code> (natural log)</li>
              <li>Constants: <code>pi</code>, <code>e</code> (e.g., <code>e^x</code>, <code>2*pi*x</code>)</li>
              <li>Composite functions: <code>sin(x^2)</code>, <code>log(cos(x))</code>, etc.</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-medium mb-2">Method Selection Guide</h3>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li><strong>Forward/Backward O(h):</strong> Simple methods, good for basic understanding</li>
              <li><strong>Central O(h²):</strong> Better accuracy for most applications with same step size</li>
              <li><strong>Forward/Backward O(h²):</strong> Higher precision while still using points only in one direction</li>
              <li><strong>Central O(h⁴):</strong> Best accuracy, recommended for high-precision calculations</li>
              <li>For boundary points (where data is only available on one side), use forward or backward methods</li>
            </ul>
          </div>
        </div>
        
        <div className="mt-6">
          <h3 className="font-medium mb-2">Example Functions to Try</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-sm">
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="font-medium">Polynomial</div>
              <code>x^2 - 3*x + 2</code>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="font-medium">Trigonometric</div>
              <code>sin(x) * cos(x)</code>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="font-medium">Exponential</div>
              <code>e^(2*x) - x^2</code>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="font-medium">Logarithmic</div>
              <code>x * log(x)</code>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="font-medium">Composite</div>
              <code>sin(x^2) / x</code>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <div className="font-medium">Rational</div>
              <code>(x^2 - 1) / (x + 2)</code>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}