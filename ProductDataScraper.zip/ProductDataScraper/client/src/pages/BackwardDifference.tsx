import { useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import Formula from "@/components/Formula";
import useMathJax from "@/hooks/useMathJax";

export default function BackwardDifference() {
  const pageRef = useRef<HTMLDivElement>(null);
  const { renderMath } = useMathJax();

  useEffect(() => {
    if (pageRef.current) {
      renderMath(pageRef.current);
    }
  }, [renderMath]);
  
  return (
    <section ref={pageRef} className="mb-12">
      <Card className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold font-inter mb-4 text-primary">Backward Difference Method</h2>
        
        <div className="mb-6">
          <h3 className="text-xl font-medium mb-3">Theoretical Foundation</h3>
          <p className="mb-4">
            The backward difference method approximates derivatives using the function values at the current point and points behind it. It is derived from the Taylor series expansion:
          </p>
          <Formula formula="f(x-h) = f(x) - f'(x)h + \frac{f''(x)h^2}{2!} - \frac{f'''(x)h^3}{3!} + \cdots" />
          
          <p className="my-4">Solving for f'(x), we get:</p>
          
          <Formula formula="f'(x) = \frac{f(x) - f(x-h)}{h} + \frac{f''(x)h}{2!} - \frac{f'''(x)h^2}{3!} + \cdots" />
          
          <p className="my-4">As h approaches zero:</p>
          
          <Formula formula="f'(x) = \lim_{h \to 0} \frac{f(x) - f(x-h)}{h}" />
          
          <p className="mt-4">This gives us the first-order backward difference approximation:</p>
          
          <Formula 
            formula="f'(x) \approx \frac{f(x) - f(x-h)}{h} + O(h)" 
            className="bg-secondary/5 border-l-4 border-secondary"
          />
        </div>
        
        <div className="mb-6">
          <h3 className="text-xl font-medium mb-3">Formula Table for Higher Order Derivatives</h3>
          <div className="overflow-x-auto">
            <table className="derivative-table w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th>Derivative</th>
                  <th>Backward Difference Formula</th>
                  <th>Truncation Error</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>First, f'(x)</td>
                  <td>{`\\( \\frac{f(x) - f(x-h)}{h} \\)`}</td>
                  <td>O(h)</td>
                </tr>
                <tr>
                  <td>Second, f''(x)</td>
                  <td>{`\\( \\frac{f(x) - 2 \\cdot f(x-h) + f(x-2h)}{h^2} \\)`}</td>
                  <td>O(h)</td>
                </tr>
                <tr>
                  <td>Third, f'''(x)</td>
                  <td>{`\\( \\frac{f(x) - 3 \\cdot f(x-h) + 3 \\cdot f(x-2h) - f(x-3h)}{h^3} \\)`}</td>
                  <td>O(h)</td>
                </tr>
                <tr>
                  <td>Fourth, f⁽⁴⁾(x)</td>
                  <td>{`\\( \\frac{f(x) - 4 \\cdot f(x-h) + 6 \\cdot f(x-2h) - 4 \\cdot f(x-3h) + f(x-4h)}{h^4} \\)`}</td>
                  <td>O(h)</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        {/* Example Problem */}
        <div className="mt-8">
          <h3 className="text-xl font-medium mb-3">Example Problem</h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="mb-2">
              <span className="font-medium">Consider the function </span>
              <Formula formula="f(x) = 9e^{4x}" />
            </div>
            <p className="mt-2">Calculate f'(0.2) using the backward difference method with h = 0.05</p>
            
            {/* Interactive Step Solution */}
            <div className="mt-4">
              <div className="border border-gray-200 rounded-lg bg-white">
                <div className="bg-primary/5 p-3 font-medium border-b border-gray-200">
                  Step-by-Step Solution
                </div>
                <div className="p-4 space-y-3">
                  <div>
                    <p className="font-medium">Step 1: Set up the backward difference formula</p>
                    <Formula formula="f'(0.2) \approx \frac{f(0.2) - f(0.2-0.05)}{0.05} = \frac{f(0.2) - f(0.15)}{0.05}" />
                  </div>
                  
                  <div>
                    <p className="font-medium">Step 2: Calculate f(0.2)</p>
                    <Formula formula="f(0.2) = 9e^{4 \cdot 0.2} = 9e^{0.8} = 9 \cdot 2.2255 = 20.0295" />
                  </div>
                  
                  <div>
                    <p className="font-medium">Step 3: Calculate f(0.15)</p>
                    <Formula formula="f(0.15) = 9e^{4 \cdot 0.15} = 9e^{0.6} = 9 \cdot 1.8221 = 16.3989" />
                  </div>
                  
                  <div>
                    <p className="font-medium">Step 4: Calculate the derivative approximation</p>
                    <Formula formula="f'(0.2) \approx \frac{20.0295 - 16.3989}{0.05} = \frac{3.6306}{0.05} = 72.612" />
                  </div>
                  
                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                    <p className="font-medium text-primary">Analytical Solution for Comparison:</p>
                    <Formula formula="f'(x) = 36e^{4x}" />
                    <p>Evaluating at x = 0.2:</p>
                    <Formula formula="f'(0.2) = 36e^{4 \cdot 0.2} = 36e^{0.8} = 36 \cdot 2.2255 = 80.118" />
                    <div>Absolute error = 7.506</div>
                    <div>Relative error = 9.37%</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </section>
  );
}
