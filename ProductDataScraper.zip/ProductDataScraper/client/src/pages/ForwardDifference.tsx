import { useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import Formula from "@/components/Formula";
import useMathJax from "@/hooks/useMathJax";

export default function ForwardDifference() {
  const pageRef = useRef<HTMLDivElement>(null);
  const { renderMath } = useMathJax();

  useEffect(() => {
    if (pageRef.current) {
      renderMath(pageRef.current);
    }
  }, [renderMath]);
  
  return (
    <section ref={pageRef} className="mb-12">
      <Card className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-semibold font-inter mb-4 text-primary">Forward Difference Method</h2>
        
        <div className="mb-6">
          <h3 className="text-xl font-medium mb-3">Theoretical Foundation</h3>
          <p className="mb-4">
            The forward difference method approximates derivatives using the function values at the current point and points ahead. It is derived from the Taylor series expansion:
          </p>
          <Formula formula="f(x+h) = f(x) + f'(x)h + \frac{f''(x)h^2}{2!} + \frac{f'''(x)h^3}{3!} + \cdots" />
          
          <p className="my-4">Solving for f'(x), we get:</p>
          
          <Formula formula="f'(x) = \frac{f(x+h) - f(x)}{h} - \frac{f''(x)h}{2!} - \frac{f'''(x)h^2}{3!} - \cdots" />
          
          <p className="my-4">As h approaches zero:</p>
          
          <Formula formula="f'(x) = \lim_{h \to 0} \frac{f(x+h) - f(x)}{h}" />
          
          <p className="mt-4">This gives us the first-order forward difference approximation:</p>
          
          <Formula 
            formula="f'(x) \approx \frac{f(x+h) - f(x)}{h} + O(h)" 
            className="bg-secondary/5 border-l-4 border-secondary"
          />
        </div>
        
        <div className="mb-6">
          <h3 className="text-xl font-medium mb-3">Formula Table for Higher Order Derivatives</h3>
          <div className="overflow-x-auto">
            <table className="derivative-table w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th>Derivative</th>
                  <th>Forward Difference Formula</th>
                  <th>Truncation Error</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>First, f'(x)</td>
                  <td>{`\\( \\frac{f(x+h) - f(x)}{h} \\)`}</td>
                  <td>O(h)</td>
                </tr>
                <tr>
                  <td>Second, f''(x)</td>
                  <td>{`\\( \\frac{f(x+2h) - 2 \\cdot f(x+h) + f(x)}{h^2} \\)`}</td>
                  <td>O(h)</td>
                </tr>
                <tr>
                  <td>Third, f'''(x)</td>
                  <td>{`\\( \\frac{f(x+3h) - 3 \\cdot f(x+2h) + 3 \\cdot f(x+h) - f(x)}{h^3} \\)`}</td>
                  <td>O(h)</td>
                </tr>
                <tr>
                  <td>Fourth, f⁽⁴⁾(x)</td>
                  <td>{`\\( \\frac{f(x+4h) - 4 \\cdot f(x+3h) + 6 \\cdot f(x+2h) - 4 \\cdot f(x+h) + f(x)}{h^4} \\)`}</td>
                  <td>O(h)</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        {/* Example - Rocket Velocity */}
        <div className="mt-8">
          <h3 className="text-xl font-medium mb-3">Example: Rocket Velocity</h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="font-medium">The velocity of a rocket is given by:</p>
            <Formula formula="v(t) = 2000 \ln\left(\frac{14 \cdot 10^4}{14 \cdot 10^4 - 2100t}\right) - 9.8t, \quad 0 \leq t \leq 30" />
            
            <p className="mt-4">Calculate the acceleration at t = 16s using forward difference with a step size of h = 2s.</p>
            
            {/* Interactive Step Solution */}
            <div className="mt-4">
              <div className="border border-gray-200 rounded-lg bg-white">
                <div className="bg-primary/5 p-3 font-medium border-b border-gray-200">
                  Step-by-Step Solution
                </div>
                <div className="p-4 space-y-3">
                  <div>
                    <p className="font-medium">Step 1: Set up the forward difference formula for the first derivative</p>
                    <Formula formula="a(16) = f'(16) \approx \frac{f(16+h) - f(16)}{h} = \frac{v(18) - v(16)}{2}" />
                  </div>
                  
                  <div>
                    <p className="font-medium">Step 2: Calculate v(16)</p>
                    <Formula formula="v(16) = 2000 \ln\left(\frac{14 \cdot 10^4}{14 \cdot 10^4 - 2100 \cdot 16}\right) - 9.8 \cdot 16" />
                    <Formula formula="v(16) = 393.62 \text{ m/s}^2" />
                  </div>
                  
                  <div>
                    <p className="font-medium">Step 3: Calculate v(18)</p>
                    <Formula formula="v(18) = 2000 \ln\left(\frac{14 \cdot 10^4}{14 \cdot 10^4 - 2100 \cdot 18}\right) - 9.8 \cdot 18" />
                    <Formula formula="v(18) = 453.02 \text{ m/s}^2" />
                  </div>
                  
                  <div>
                    <p className="font-medium">Step 4: Calculate the approximation of acceleration</p>
                    <Formula formula="a(16) \approx \frac{453.02 - 393.62}{2} = \frac{59.4}{2} = 29.7 \text{ m/s}^2" />
                  </div>
                  
                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                    <p className="font-medium text-primary">Analytical Solution for Comparison:</p>
                    <Formula formula="a(t) = \frac{d}{dt}v(t) = \frac{4.2 \cdot 10^6}{(14 \cdot 10^4 - 2100t)} - 9.8" />
                    <p>Evaluating at t = 16:</p>
                    <Formula formula="a(16) = 29.674 \text{ m/s}^2" />
                    <p>Error = 0.088%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </section>
  );
}
