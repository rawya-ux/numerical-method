import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import ForwardDifference from "@/pages/ForwardDifference";
import BackwardDifference from "@/pages/BackwardDifference";
import CentralDifference from "@/pages/CentralDifference";
import RichardsonExtrapolation from "@/pages/RichardsonExtrapolation";
import HigherOrderFormulas from "@/pages/HigherOrderFormulas";
import InteractiveSolver from "@/pages/InteractiveSolver";
import Tutorial from "@/pages/Tutorial";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/forward" component={ForwardDifference} />
      <Route path="/backward" component={BackwardDifference} />
      <Route path="/central" component={CentralDifference} />
      <Route path="/richardson" component={RichardsonExtrapolation} />
      <Route path="/higher-order" component={HigherOrderFormulas} />
      <Route path="/solver" component={InteractiveSolver} />
      <Route path="/tutorial" component={Tutorial} />
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <TooltipProvider>
      <Toaster />
      <Layout>
        <Router />
      </Layout>
    </TooltipProvider>
  );
}

export default App;
