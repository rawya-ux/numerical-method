/**
 * This utility converts between LaTeX expressions and math.js compatible syntax
 */

/**
 * Converts LaTeX notation to mathjs-compatible expression
 * 
 * @param latex LaTeX expression
 * @returns mathjs-compatible expression string
 */
export function latexToMathJs(latex: string): string {
  if (!latex || latex.trim() === '') return '';
  
  let expression = latex
    // Handle fractions
    .replace(/\\frac{([^{}]*)}{([^{}]*)}/g, '($1)/($2)')
    .replace(/\\frac{([^{}]*)}{([^{}]*)}/g, '($1)/($2)') // nested fractions
    
    // Handle powers
    .replace(/\^{([^{}]*)}/g, '^($1)')
    
    // Handle square roots
    .replace(/\\sqrt{([^{}]*)}/g, 'sqrt($1)')
    
    // Handle trig functions
    .replace(/\\sin/g, 'sin')
    .replace(/\\cos/g, 'cos')
    .replace(/\\tan/g, 'tan')
    .replace(/\\csc/g, 'csc')
    .replace(/\\sec/g, 'sec')
    .replace(/\\cot/g, 'cot')
    
    // Handle log/ln functions
    .replace(/\\log/g, 'log10')
    .replace(/\\ln/g, 'log')
    
    // Handle exponential
    .replace(/\\exp{([^{}]*)}/g, 'exp($1)')
    .replace(/\\exp/g, 'exp')
    
    // Handle special constants
    .replace(/\\pi/g, 'pi')
    .replace(/\\theta/g, 'theta')
    .replace(/\\e/g, 'e')
    
    // Handle multiplication
    .replace(/\\cdot/g, '*')
    .replace(/\\times/g, '*')
    
    // Clean up any remaining LaTeX commands
    .replace(/\\/g, '')
    .replace(/\{/g, '(')
    .replace(/\}/g, ')')
    .replace(/\[/g, '')
    .replace(/\]/g, '');
  
  // Handle implied multiplication (e.g., 2x → 2*x)
  expression = expression.replace(/([0-9])([a-zA-Z])/g, '$1*$2');
  
  return expression;
}

/**
 * Converts mathjs-compatible expression to LaTeX
 * This is a simple conversion and may not handle all cases.
 * 
 * @param expression mathjs-compatible expression
 * @returns LaTeX string
 */
export function mathJsToLatex(expression: string): string {
  if (!expression || expression.trim() === '') return '';
  
  return expression
    // Handle powers
    .replace(/\^\(([^()]+)\)/g, '^{$1}')
    .replace(/\^([a-zA-Z0-9])/g, '^{$1}')
    
    // Handle square roots
    .replace(/sqrt\(([^()]+)\)/g, '\\sqrt{$1}')
    
    // Handle trig functions
    .replace(/sin\(/g, '\\sin(')
    .replace(/cos\(/g, '\\cos(')
    .replace(/tan\(/g, '\\tan(')
    .replace(/csc\(/g, '\\csc(')
    .replace(/sec\(/g, '\\sec(')
    .replace(/cot\(/g, '\\cot(')
    
    // Handle log/ln functions
    .replace(/log10\(/g, '\\log(')
    .replace(/log\(/g, '\\ln(')
    
    // Handle exponential
    .replace(/exp\(/g, '\\exp(')
    
    // Handle special constants
    .replace(/\bpi\b/g, '\\pi')
    .replace(/\btheta\b/g, '\\theta')
    
    // Handle multiplication
    .replace(/\*/g, '\\cdot');
}
