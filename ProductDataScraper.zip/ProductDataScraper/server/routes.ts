import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Static content delivery for the educational numerical differentiation tool
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'Numerical Differentiation Educational Tool API' });
  });

  const httpServer = createServer(app);

  return httpServer;
}
