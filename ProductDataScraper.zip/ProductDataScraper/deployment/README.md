# Numerical Differentiation Educational App

An advanced educational platform for numerical differentiation, providing comprehensive and interactive mathematical learning experiences through innovative visualization and engagement techniques.

## Features

- Interactive equation editor using MathLive
- Comprehensive formulas up to 4 derivatives
- Multiple differentiation methods (Forward, Backward, Central, etc.)
- Higher-order methods with O(h²) and O(h⁴) accuracy
- Step-by-step solutions with explanations

## Setup & Development

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Run development server**
   ```bash
   npm run dev
   ```

3. **Build for production**
   ```bash
   npm run build
   ```

## Deployment

### Netlify Deployment (Free)

1. Connect this GitHub repository to Netlify
2. Use these build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`

### GitHub Pages Deployment (Free)

1. Run `npm run build`
2. Set up GitHub Pages to deploy from the `dist` folder

## Technology Stack

- React + TypeScript
- MathLive for equation editing
- MathJax for formula rendering
- math.js for numerical calculations
